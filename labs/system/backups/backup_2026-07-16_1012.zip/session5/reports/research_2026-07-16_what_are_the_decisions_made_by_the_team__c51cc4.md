# Research Report

Question: What are the decisions made by the team regarding employment?
Date: 2026-07-16

---

## Summary
The team has made several decisions regarding employment and business strategy, but one key decision is still pending: whether to enter the market with actual revenue or just usage numbers. The founder has mentioned that they need to decide on this before any investment round.

## What We Know
* The team has decided to focus on small restaurants in the first phase (Source: خطة_العمل.md, Decision).
* They have also decided to delay supporting English language in the interface until the second phase (Source: خطة_العمل.md, Decision).
* The founder will be the first salesperson and will learn about customer complaints directly (Source: محادثة_استشارية.txt, Decision).
* The team has decided to enter the market with actual revenue, not just usage numbers (Source: قرار_مجلس_استشاري_توسّع_السلاسل.md, Decision).

## Evidence
* 71% of restaurant owners in a small study reported losing over $300 per month due to poor inventory management (Source: دراسة_سوق_مصغرة.md, Evidence).
* 58% of participants were willing to pay between $50 and $150 per month for a solution that reduces this waste (Source: دراسة_سوق_مصغرة.md, Evidence).

## Related Decisions
* The team has decided to delay hiring a dedicated salesperson until they reach 20 paying customers from small restaurants (Source: قرار_مجلس_استشاري_توسّع_السلاسل.md, Decision).
* They have also decided to focus on large restaurant chains and high-end restaurants in the next phase (Source: قرار_مجلس_استشاري_توسّع_السلاسل.md, Decision).

## Related Open Questions
* Whether to enter the market with actual revenue or just usage numbers is still an open question (Source: محادثة_استشارية.txt, Open Question).
* How to integrate with existing ERP systems in large restaurant chains is also an open question (Source: قرار_مجلس_استشاري_توسّع_السلاسل.md, Open Question).

## Knowledge Limits
The archive does not provide information on the specific steps the team will take to implement their decision to enter the market with actual revenue.
