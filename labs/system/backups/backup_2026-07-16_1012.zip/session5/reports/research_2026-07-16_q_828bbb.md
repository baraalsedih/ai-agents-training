# Research Report

Question: كم عدد العملاء التجريبيين الذين تستخدم منصة خزين حاليًا مجانًا، ولأي مدة؟
Date: 2026-07-16

---

## Summary
There are currently 6 experimental customers using the "Khazin" platform for free, and they will be able to use it for an unspecified period of time. The platform is still in its early stages, and the team has not yet decided on a pricing model or a specific duration for the free trial.

## What We Know
* The team has been testing the platform with 6 customers who agreed to try out the version 1.0 (Source: ملاحظات_اجتماع.txt, Category: Decision).
* These customers are primarily small restaurants and cafes, as decided in the initial plan (Source: خطة_العمل.md, Category: Idea).
* The team has not yet decided on a pricing model or a specific duration for the free trial (Source: ملاحظات_اجتماع.txt, Category: Decision).

## Evidence
There is no concrete evidence of the number of customers using the platform for free. However, we do know that 5 out of 6 experimental customers mentioned that they struggle with knowing when to order supplies, which led to the decision to prioritize "instant stock alerts" as a key feature in the initial launch (Source: ملاحظات_اجتماع.txt, Category: Decision).

## Related Decisions
* The team has decided to focus on small restaurants and cafes for the first phase of the platform, rather than larger chains or high-end restaurants (Source: خطة_العمل.md, Category: Idea).
* The team has also decided to prioritize "instant stock alerts" as a key feature in the initial launch, rather than the weekly inventory report that was initially planned (Source: ملاحظات_اجتماع.txt, Category: Decision).

## Related Open Questions
* There is still an open question about how to integrate sales with larger chains and high-end restaurants, which was discussed in the council meeting (Source: قرار_مجلس_استشاري_توسّع_السلاسل.md, Category: Open Question).
* The team also needs to decide on a pricing model for the platform, which is still an open question (Source: ملاحظات_اجتماع.txt, Category: Decision).

## Knowledge Limits
The archive does not provide information on the specific duration of the free trial or the pricing model that will be used after the initial launch.
